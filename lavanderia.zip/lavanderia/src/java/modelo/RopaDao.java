/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Samir
 */
public class RopaDao {
    Connection conn = null;
    PreparedStatement stmt = null;
    Statement sta= null;
    ResultSet rs;

    public String CrearRopa(Ropa ropa) {
        conn = conexion.crearConexion();
        String regropa = "";
        try {
           
            stmt = conn.prepareStatement("INSERT INTO ropa VALUES(NULL,?,?,?,?,NOW())");
            stmt.setString(1, ropa.getTipo());
            stmt.setString(2, ropa.getFecha());
            stmt.setString(3, ropa.getNombre());
            stmt.setString(4, ropa.getUsuario());

            stmt.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(UsuariosDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return regropa;
}
}
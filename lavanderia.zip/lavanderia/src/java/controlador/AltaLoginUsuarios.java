/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.Hash;
import modelo.conexion;

/**
 *
 * @author ingAn
 */
@WebServlet(name = "ServletAltaLoginUsuarios", urlPatterns = {"/ServletAltaLoginUsuarios"})
public class AltaLoginUsuarios extends HttpServlet {

    ResultSet resultado;
    Connection con;
    Statement sentencia;


    String nusu = "";
    String idclave = "";
    int nrol;

    ServletContext sc = null;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
//Extraigo el contexto del servlet
        sc = this.getServletContext();

    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        
 HttpSession ses = request.getSession(true);
        try {
//Se recogen los parametros a compar en la base de datos
            String usu = request.getParameter("cusuario");
            String clave = request.getParameter("cclave");
            String cla = Hash.md5(clave);
            con = conexion.crearConexion();
            sentencia = con.createStatement();

            resultado = sentencia.executeQuery("SELECT * FROM usuarios where usuario='" + usu + "' and clave ='" + cla + "'");

            while (resultado.next()) {
                nusu = resultado.getString("usuario");
                idclave = resultado.getString("clave");
                nrol = Integer.parseInt(resultado.getString("perfil"));
            }

            if (usu.equals("") && cla.equals("")) {
                out.println("Contraseña Invalida");
            }
            if (usu.equals(nusu) && cla.equals(idclave)) {
//Captuara de datos para mantener la session.
                HttpSession sesion_cli = request.getSession(true);
                sesion_cli.setAttribute("nUsuario", request.getParameter("cusuario"));
                sesion_cli.setAttribute("pClave", request.getParameter("cclave"));
//Validación de usuario y contraseña
//Admon Sistema
                if (nrol == 1) {
                    sc.getRequestDispatcher("/indexUsuario.jsp").forward(request, response);
                     RequestDispatcher rs = request.getRequestDispatcher("indexUsuario.jsp");
        rs.forward(request, response);
                } //Admon 2
                else if (nrol == 2) {
                    sc.getRequestDispatcher("/indexAdministrador.jsp").forward(request, response);
                     RequestDispatcher rs = request.getRequestDispatcher("indexAdministrador.jsp");
        rs.forward(request, response);
                }
                else if (nrol == 3) {
                    sc.getRequestDispatcher("/indexSecretaria.jsp").forward(request, response);
                     RequestDispatcher rs = request.getRequestDispatcher("indexAdministrador.jsp");
        rs.forward(request, response);
                }
            }

        } catch (Exception e) {
            ses.setAttribute("mensaje", "Usuario no encontrado.");
            ses.setAttribute("exc", e.toString());
        }
        sentencia.close();
        con.close();
        ses.setAttribute("titulo", "Control de Acceso");
        sc.getRequestDispatcher("/login.jsp").forward(request, response);


    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(AltaLoginUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(AltaLoginUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
